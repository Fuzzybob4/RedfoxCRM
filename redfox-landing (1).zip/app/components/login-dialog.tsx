"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { supabase } from "@/lib/supabase"
import { useAuth } from "./auth-provider"

export function LoginDialog() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [open, setOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const { setIsLoggedIn } = useAuth()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/auth/v1/token?grant_type=password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string,
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (!response.ok) {
        let errorMessage = "An unexpected error occurred. Please try again."

        switch (data.error_description) {
          case "Invalid login credentials":
            errorMessage = "Invalid email or password. Please check your credentials and try again."
            break
          case "Email not confirmed":
            errorMessage = "Please confirm your email address before logging in."
            break
          case "User not found":
            errorMessage = "No account found with this email. Please sign up if you haven't already."
            break
          case "Too many requests":
            errorMessage = "Too many login attempts. Please try again later."
            break
          default:
            if (data.error_description) {
              errorMessage = data.error_description
            }
        }

        toast({
          title: "Login Failed",
          description: errorMessage,
          variant: "destructive",
        })
        return
      }

      if (!data.user) {
        toast({
          title: "Login Failed",
          description: "No user data returned. Please try again.",
          variant: "destructive",
        })
        return
      }

      console.log("Login successful:", data)
      setIsLoggedIn(true)
      toast({
        title: "Login Successful",
        description: "You have been logged in successfully.",
      })
      setOpen(false)
      router.push(`/dashboard/${data.user.id}`)

      // Update the Supabase client with the new session
      await supabase.auth.setSession({
        access_token: data.access_token,
        refresh_token: data.refresh_token,
      })
    } catch (err) {
      console.error("Login error:", err)
      toast({
        title: "Login Error",
        description: "An unexpected error occurred. Please try again later.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="bg-white text-[#08042B] hover:bg-[#F5F906] px-6 py-3 text-lg">
          Login
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] bg-[#08042B] text-white">
        <DialogHeader>
          <DialogTitle>Login to RedFox CRM</DialogTitle>
          <DialogDescription>Enter your email and password to access your account.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
              required
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-[#F67721] hover:bg-[#F5F906] hover:text-[#08042B] text-white"
            disabled={isLoading}
          >
            {isLoading ? "Logging in..." : "Log In"}
          </Button>
        </form>
        <div className="mt-4 text-center space-y-2">
          <Link
            href="/reset-password"
            className="text-[#F67721] hover:text-[#F5F906] block"
            onClick={() => setOpen(false)}
          >
            Forgot your password?
          </Link>
          <Link href="/login" className="text-[#F67721] hover:text-[#F5F906] block" onClick={() => setOpen(false)}>
            Go to full login page
          </Link>
        </div>
      </DialogContent>
    </Dialog>
  )
}

