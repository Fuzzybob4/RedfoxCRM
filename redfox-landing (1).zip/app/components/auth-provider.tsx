"use client"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import type { ReactNode } from "react"
import type { User } from "@supabase/supabase-js"

interface AuthContextType {
  user: User | null
  isLoggedIn: boolean
  loading: boolean
  setIsLoggedIn: (value: boolean) => void
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoggedIn: false,
  loading: true,
  setIsLoggedIn: () => {},
})

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      setUser(user)
      setIsLoggedIn(!!user)
      setLoading(false)
    }
    getUser()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN") {
        setUser(session?.user ?? null)
        setIsLoggedIn(true)
        router.refresh()
      } else if (event === "SIGNED_OUT") {
        setUser(null)
        setIsLoggedIn(false)
        router.refresh()
      }
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [router])

  return <AuthContext.Provider value={{ user, isLoggedIn, loading, setIsLoggedIn }}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)

